/*
 * Copyright (C) 2026 yztz
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package top.yztz.gingerbulkmessenger.data;


import android.content.Context;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import top.yztz.gingerbulkmessenger.exception.DataLoadFailed;
import top.yztz.gingerbulkmessenger.services.SMSSender;
import top.yztz.gingerbulkmessenger.util.ExcelReader;
import top.yztz.gingerbulkmessenger.util.HashUtils;

public class DataModel implements Serializable {
    private static String[] titles = null;
    private static String path;
    private static long timestamp;
    private static String template;
    private static String numberColumn;
    private static String signature;
    private static int subId;
    private static List<HashMap<String, String >> data = null;

    private static boolean loaded = false;

    /** Duplicate rows the user chose to send again. Compared by identity, cleared on every load. */
    private static final Set<HashMap<String, String>> allowedDuplicates =
            Collections.newSetFromMap(new IdentityHashMap<>());

    /** A row whose phone number already appeared in an earlier row. */
    public static class DuplicateEntry {
        public final String number;
        public final HashMap<String, String> row;
        public final HashMap<String, String> firstRow;

        DuplicateEntry(String number, HashMap<String, String> row, HashMap<String, String> firstRow) {
            this.number = number;
            this.row = row;
            this.firstRow = firstRow;
        }
    }

    public static boolean loaded() {
        return loaded;
    }

    /**
     * Must be called in the non-UI thread
     *
     * @param path    excel file to load
     */
    public static synchronized void load(String path) throws DataLoadFailed {
        ExcelReader reader = new ExcelReader();
        reader.read(path);
        DataModel.data = reader.readExcelContent();
        DataModel.titles = reader.getTitles();
        DataModel.path = path;
        DataModel.signature = HashUtils.toMd5(path + "+" + String.join("-", reader.getTitles()));
        DataModel.timestamp = System.currentTimeMillis();

        allowedDuplicates.clear();
        DataModel.template = "";
        DataModel.numberColumn = "";
        DataModel.subId = SMSSender.getDefaultSubID();
        loaded = true;
    }

    public static void saveAsHistory(Context context) {
        assert loaded();
        HistoryManager.addHistory(context, path, template, subId, numberColumn, signature);
    }

    public static int getRowCount() {
        return data.size();
    }

    public static HashMap<String, String> getRow(int index) {
        return data.get(index);
    }

    public static String[] getTitles() {
        return titles;
    }

    public static String getPath() {
        return path;
    }

    public static long getTimestamp() {
        return timestamp;
    }

    public static String getTemplate() {
        return template;
    }

    public static void setTemplate(String template) {
        DataModel.template = template;
    }

    public static String getNumberColumn() {
        return numberColumn;
    }

    public static void setNumberColumn(String numberColumn) {
        DataModel.numberColumn = numberColumn;
    }

    public static String getSignature() {
        return signature;
    }


    public static int getSubId() {
        return subId;
    }

    public static void setSubId(int subId) {
        DataModel.subId = subId;
    }

    /**
     * Rows whose phone number (trimmed, exact text) already appeared in an earlier row.
     * Rows the user already chose to send again are not reported a second time.
     * Does not modify the data.
     */
    public static List<DuplicateEntry> findDuplicates() {
        List<DuplicateEntry> result = new ArrayList<>();
        if (!loaded || numberColumn == null || numberColumn.isEmpty()) return result;

        java.util.Map<String, HashMap<String, String>> first = new HashMap<>();
        for (HashMap<String, String> row : data) {
            String number = numberOf(row);
            if (number.isEmpty()) continue;
            HashMap<String, String> earlier = first.get(number);
            if (earlier == null) {
                first.put(number, row);
            } else if (!allowedDuplicates.contains(row)) {
                result.add(new DuplicateEntry(number, row, earlier));
            }
        }
        return result;
    }

    /**
     * Removes rows with an empty phone number and every duplicate row except those in
     * {@code sendAgain}, which are kept (and remembered, so they are not flagged again).
     *
     * @return number of rows removed
     */
    public static int applyDuplicateChoice(Collection<HashMap<String, String>> sendAgain) {
        if (!loaded || numberColumn == null || numberColumn.isEmpty()) return 0;
        allowedDuplicates.addAll(sendAgain);

        int originalCount = data.size();
        Set<String> seen = new HashSet<>();
        Iterator<HashMap<String, String>> iterator = data.iterator();
        while (iterator.hasNext()) {
            HashMap<String, String> row = iterator.next();
            String number = numberOf(row);
            if (number.isEmpty()) {
                iterator.remove();
            } else if (!seen.add(number) && !allowedDuplicates.contains(row)) {
                iterator.remove();
            }
        }
        return originalCount - data.size();
    }

    private static String numberOf(HashMap<String, String> row) {
        String number = row.get(numberColumn);
        return number == null ? "" : number.trim();
    }

    public static void clear() {
        allowedDuplicates.clear();
        data = null;
        titles = null;
        loaded = false;
    }
}
